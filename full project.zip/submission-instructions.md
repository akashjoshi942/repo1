# Project Submission Instructions

## Repository Submission Requirements
Each team will be required to submit a GitHub repository with their project. The GitHub repos **must** meet the following criteria:

1. Repository must live within the https://github.com/finos-labs GitHub Org.
2. Completion of `README.md` details.
    - Project Name
    - Team Information
3. All the code should be submitted on June 11th before 5.00PM IST
