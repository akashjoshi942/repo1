# Code of Conduct for FINOS Hackathon Events

Please see the [Community Code of Conduct](https://www.finos.org/code-of-conduct).
