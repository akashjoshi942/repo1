import { Component } from '@angular/core';

@Component({
  selector: 'app-user.show.data.component',
  imports: [],
  templateUrl: './user.show.data.component.html',
  styleUrl: './user.show.data.component.css'
})
export class UserShowDataComponent {

}
